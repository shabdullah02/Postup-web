"use client"

import PlatformTile from "./hero-tile"

/**
 * Postup's homepage hero, restyled around the supplied Mixpost reference.
 * Keeps Postup's existing message and CTA wording while adopting the
 * reference's purple typography, warm canvas, open spacing and layered art.
 */
export default function PostupHero() {
  return (
    <section className="postup-hero" aria-labelledby="postup-hero-title">
      <div className="postup-hero__copy">
        <h1 id="postup-hero-title">
          Schedule once.<br />
          Post everywhere<br />
          you’re active.
        </h1>

        <p className="postup-hero__description">
          Plan your content, keep your publishing queue full, and track follower
          and reach analytics for Facebook, Instagram and Threads, all from one
          calm workspace.
        </p>

        <div className="postup-hero__actions">
          <a className="postup-hero__button postup-hero__button--primary" href="/register">
            Start for free <span aria-hidden="true">→</span>
          </a>
          <a className="postup-hero__button postup-hero__button--secondary" href="#features">
            See how it works
          </a>
        </div>

        <p className="postup-hero__note">Connect a Page in minutes.</p>
      </div>

      <div className="postup-hero__art" aria-hidden="true">
        <PlatformTile />
      </div>
    </section>
  )
}
