POSTUP HERO REDESIGN — integration notes

Files
- hero-tile.tsx: updated supplied PlatformTile component; outline slabs now use
  the reference's pale lavender stroke rather than the theme's orange primary.
- postup-hero.tsx: replacement hero content/layout. It preserves the current
  Postup headline, description, and CTA labels.
- postup-hero.css: visual styles and the stronger structural page frame.

Integration
1. Replace the existing hero section with <PostupHero />.
2. Import the stylesheet once in the page or app entry point:
     import "./postup-hero.css"
3. Wrap the existing navbar and hero together in:
     <div className="postup-page-frame"> ... </div>
4. Add className="postup-site-header" to the existing navbar element. Keep
   its existing navigation and account controls; this class only adds the
   89px header height and stronger bottom divider.

Notes
- The CSS uses the current screenshot's copy and button wording, not Mixpost's
  product copy. Update /register and #features if your actual routes differ.
- The provided source was only PlatformTile, not the page/navbar component, so
  the navbar itself is intentionally not rewritten here.
